from setup import *
setup()