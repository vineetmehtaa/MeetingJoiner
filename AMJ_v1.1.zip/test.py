import validators

s = "http"

print(validators.url(s))