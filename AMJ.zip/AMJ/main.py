from functions import findLinkAndLaunch
from setup import setup
import validators

config = open("details.txt", "r")
check = config.readlines()
config.close()

if len(check) == 3 and check[0][-6:-4] == "PU" and validators.url(check[1]) and validators.url(check[2]):
	findLinkAndLaunch()

else:
	input("Welcome to setup! Enter any key to start configuration...")
	setup()